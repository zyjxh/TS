export function add(x: number, y: number) {
    return x + y
}

// add(1, '2')