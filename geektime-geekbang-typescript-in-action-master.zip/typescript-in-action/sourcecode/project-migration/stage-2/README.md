实战篇 渐进式迁移策略
===============

JavaScript to TypeScript 宽松策略