// 导出常量
export const str = 'Hello'