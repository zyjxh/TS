export = function () {
    console.log("I'm default")
}
// export let a = 1