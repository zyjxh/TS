let a = {
    x: 1,
    y: 2
}

// 整体导出
module.exports = a
