import Client = require('../src/client')

let c = new Client()

// do test