import { getTime } from '../common'

console.log(`Client Time: ${getTime()}`)

class Client {}

export = Client